import bdd.angular.po.DocsPage;
import bdd.angular.po.LandingHome;
import bdd.angular.po.TopNavigation;
import cucumber.api.PendingException;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class MyStepdefs {

    LandingHome landingHome;
    TopNavigation topNavigation;
    DocsPage docsPage;

    @Given("^I want to buy a wool scarf$")
    public void i_want_to_buy_a_wool_scarf() throws Exception {
        System.out.println("1");
    }

    @When("^I search for items containing 'wool'$")
    public void i_search_for_items_containing_wool() throws Exception {
        System.out.println("2");
    }

    @Then("^I should only see items related to 'wool'$")
    public void i_should_only_see_items_related_to_wool() throws Exception {
        System.out.println("3");
    }

    @Given("^I navigate to Angular IO Page$")
    public void iNavigateToAngularIOPage() throws Throwable {
        landingHome.navigateToLandingHome();
    }

    @And("^I wait for Angular IO Page to load successfully$")
    public void iWaitForAngularIOPageToLoadSuccessfully() throws Throwable {
        landingHome.verifyLandingHome();
    }

    @When("^I click on \"([^\"]*)\" link in top navigation bar$")
    public void iClickOnLinkInTopNavigationBar(String tabText) throws Throwable {
        topNavigation.clickTabWithText(tabText);
    }

    @Then("^I should be navigated to docs page$")
    public void iShouldBeNavigatedToDocsPage() throws Throwable {
        docsPage.verifyDocsPage();
    }
}
