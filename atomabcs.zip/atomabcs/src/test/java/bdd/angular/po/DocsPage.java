package bdd.angular.po;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.thucydides.core.pages.PageObject;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class DocsPage extends PageObject {

    @FindBy(css = ".vertical-menu-item")
    private WebElement verticalMenu;

    public void verifyDocsPage() {
        waitFor(ExpectedConditions.visibilityOf(verticalMenu));
    }

}
