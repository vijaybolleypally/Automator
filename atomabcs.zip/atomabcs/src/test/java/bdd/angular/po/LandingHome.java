package bdd.angular.po;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.thucydides.core.pages.PageObject;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class LandingHome extends PageObject {

    @FindBy(css = ".hero-logo>img[src='assets/images/logos/angular/angular.svg']")
    private WebElement angularLogo;

    public void navigateToLandingHome(){
        getDriver().get("https://angular.io");
        verifyLandingHome();
    }

    public void verifyLandingHome(){
        waitFor(ExpectedConditions.visibilityOf(angularLogo));
    }

}
