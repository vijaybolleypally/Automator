package bdd.angular.po;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.thucydides.core.pages.PageObject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class TopNavigation extends PageObject {

    @FindBy(css = "a.nav-link.home img[title='Home']")
    private WebElement angularNavigationImg;

    public void navigateToAIHome() {
        waitFor(ExpectedConditions.visibilityOf(angularNavigationImg));
        angularNavigationImg.click();
    }

    public void clickTabWithText(String linkText) {
        WebElement reqWele = getDriver().findElement(By.xpath("//a[@class= 'nav-link'][contains(text(),'" + linkText + "')]"));
        waitFor(ExpectedConditions.visibilityOf(reqWele));
        reqWele.click();
    }
}
